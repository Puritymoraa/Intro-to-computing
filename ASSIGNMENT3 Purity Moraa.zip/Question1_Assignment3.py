# Question 1
# A function that takes a list as a parameter and returns
# the index of the smallest value in the list using the
# using the built-in function called min
def min_index(x):
    minimum_value = min(x)
    index_minimum_value = x.index(minimum_value)
    print(index_minimum_value)
    return index_minimum_value
min_index([40,50,10,90,100,70])
    
