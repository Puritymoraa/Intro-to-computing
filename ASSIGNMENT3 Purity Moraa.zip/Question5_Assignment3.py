# Question 5

def pairwise_ratio(list1,list2):
    """ This function takes two lists as parameters and returns a new list
        containing the ratio of the values in the first list to those in the
        second list"""
    ratio_value = 0
    ratio_list = []
    if len(list1) == len(list2):
        for i in range(len(list1)):
            ratio_value = list1[i]/list2[i]
            new_ratio_value = round(ratio_value, 3)
            ratio_list.append(new_ratio_value)
    else:
        print("The two lists are not of equal lengths")
    print(ratio_list)
    return ratio_list
pairwise_ratio([40, 50, 10, 90] ,[60, 20, 19, 95])
            