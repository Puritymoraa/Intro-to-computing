# Question 4

def pairwise_product(list1, list2):
    """ A function that takes two lists as parameters, and returns a new list
        containing the product of the values in the first list
        with those in the second list."""
    product_list = []
    product_value = 0
    if len(list1) == len(list2):
        for i in range(len(list2)):
            product_value = list1[i] *list2[i]
            product_list.append(product_value)
    else:
        print("The two lists are not of equal length")
    return product_list
pairwise_product([40, 50, 10, 90], [6, 2, 2, 5])

            
        
