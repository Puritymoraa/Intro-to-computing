# Question 3
import sys
from Part2Question1_Assignment3 import name_of_country
from Part2Question1_Assignment3 import population
from Part2Question1_Assignment3 import internet_users
from Part2Question1_Assignment3 import mobile_subscriptions


def new_countrydata_file():
    """This function will store the name of the country, mobile subscriptions per capita and 
    internet users per capita data into a file"""

    # Create lists to store new data
    mobile_subscriptions_capita = []
    internet_users_capita = []

    for index in range(len(name_of_country)):
        # per capita means value divided my the population
        mobile_subscriptions_capita = mobile_subscriptions[index] / population[index]
        internet_users_capita = internet_users[index] / population[index]

        mobile_subscriptions_capita.append(round(mobile_subscriptions_capita, 3))
        internet_users_capita.append(round(internet_users_capita, 3))

    # Files are streams of data.
    # Using the `print` function writes its arguments to the system's standard output.
    # If the standard output is changed to a file, then the print function displays the 
    # value inside the file rather than the default standard output

    # setting the standard output to a file
    sys.stdout = open("NewCountryDataInfo.txt", "w")

    print("{0:^100}".format("COUNTRY DATA"))
    print('-'*100)
    print(
        "{0:^35}{1:^35}{2:^30}"
        .format("Country Name", 
        "Mobile subscriptions per capita", "Internet users per capita")
    )
    print('-'*100)

    for index in range(len(name_of_country)):
        print(
            "{0:<35}{1:^35}{2:^30}"
            .format(name_of_country[index], 
            mobile_subscriptions_capita[index], internet_users_capita[index])
        )

    sys.stdout.close()


# calling function
new_countrydata_file()