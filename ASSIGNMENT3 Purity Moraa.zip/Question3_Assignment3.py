# Question3
def smaller_indices(list1,list2):
    """ A function that takes two lists, checks if they have the same length
        if they do, it returns a new list containing the index for which the
        value of the first list is smaller than the value in the second list"""
    indices_list = []
    if len(list1) == len(list2):
        for i in range(len(list1)):
            if list1[i] < list2[i]:
                indices_list.append(i)
    else:
        print("The two lists are not of equal lengths")
    return indices_list
smaller_indices([40,50,10,90,100,70], [60, 20, 19, 95, 30, 20])
        
    