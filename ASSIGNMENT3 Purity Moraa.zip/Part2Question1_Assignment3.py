# PART 2
# Question 1
# The program below opens and reads a csv file called CountryData, stores information in it in their respective
# lists and stores the name of the countries as the key in a dictionary with their index in the list as the value
# The program then prints the lists of the items below and a dictionary containing the countries in the list as keys
# their index in the list as values.

file = open('CountryData.csv', 'r')
file_lines = file.readlines()
name_of_country = []
population = []
literacy_rates = []
mobile_subscriptions = []
internet_users = []
electricity_production = []
electricity_consumption = []
country_dict = {}

  
for i, file_lines in enumerate(file_lines):    
    if i == 0:
        continue 
    value = file_lines.strip().split(',')  # Using the split function to split by comma for the file
    name_of_country.append(value[0])
    population.append(int(value[1]))
    literacy_rates.append(float(value[2]))
    mobile_subscriptions.append(int(value[3]))
    internet_users.append(int(value[4]))
    electricity_production.append(float(value[5]))
    electricity_consumption.append(float(value[6]))
    country_dict[value[0]] = i
print("\nThe names of the countries are: ", name_of_country)
print("\nThe population of each country is: ", population)
print("\nThe Literacy Rates are: ", literacy_rates)
print("\nThe mobile subscriptions include: ", mobile_subscriptions)
print("\nThe number of internet users are: ", internet_users)
print("\nThe list of electricity production is: ", electricity_production)
print("\nThe list of electricity consumption is:", electricity_consumption)
print("\nCountry Index Dictionary:", country_dict)
