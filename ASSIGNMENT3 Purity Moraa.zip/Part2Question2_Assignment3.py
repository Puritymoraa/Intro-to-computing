# PART 2
# Question 2
# The function below allows the user to efficiently query information about any country
# by entering the country name. It then looks up the index of the country in the dictionary
# it should then use the index to access the appropriate data for the country stored in the
# various lists, and report the data to the user. The function makes use of string formatting
#to present the numbers in the appropriate format with commas to show thousands and % to indicate percentage.

file = open('CountryData.csv', 'r')
file_lines = file.readlines()
name_of_country = []
population = []
literacy_rates = []
mobile_subscriptions = []
internet_users = []
electricity_production = []
electricity_consumption = []
country_dict = {}

  
for i, file_lines in enumerate(file_lines):    
    if i == 0:
        continue 
    value = file_lines.strip().split(',')  # Using the split function to split by comma for the file
    name_of_country.append(value[0])
    population.append(int(value[1]))
    literacy_rates.append(float(value[2]))
    mobile_subscriptions.append(int(value[3]))
    internet_users.append(int(value[4]))
    electricity_production.append(float(value[5]))
    electricity_consumption.append(float(value[6]))
    country_dict[value[0]] = i

def new_country_data():
    country_name = input("Enter the name of the country with the first letter in capital and the rest in small letter: ")
    try:
        index = country_dict[country_name]
        new_index = index - 1        
        new_poulation = "{:,}".format(population[new_index])
        new_literacy_rate = "{:.2f}%".format(literacy_rates[new_index])
        new_mobile_subscriptions = "{:,}".format(mobile_subscriptions[new_index])
        new_internet_users = "{:,}".format(internet_users[new_index])
        new_electricity_production = "{:,}".format(int(electricity_production[new_index]))
        new_electricity_consumption = "{:,}".format(int(electricity_consumption[new_index]))

        print(f"{country_name} has a population of {new_poulation} and a literacy rate of {new_literacy_rate}.")
        print(f"The estimate of the number of mobile subscriptions is {new_mobile_subscriptions}, while that of internet users is {new_internet_users}.")
        print(f"{country_name} produces {new_electricity_production} KWh of electricity annually, while it consumes {new_electricity_consumption} KWh of electricity.")
    except KeyError:
        print("The country entered does not exist. Try again!!")


new_country_data()

