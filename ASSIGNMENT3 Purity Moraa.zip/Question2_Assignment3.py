# Question 2
# A function that takes a list as a parameter and returns
# the index of the largest value in the list using the
# using the built-in function called max
def max_index(x):
    maximum_value = max(x)
    index_maximum_value = x.index(maximum_value)
    print(index_maximum_value)
    return index_maximum_value
max_index([40,50,10,90,100,70])