def age():
    in_months = int(input("Please enter your age in months = "))
    years = in_months//12
    months = in_months%12
    print("You are ", years, "year(s) and", months, "month(s) old")
age()