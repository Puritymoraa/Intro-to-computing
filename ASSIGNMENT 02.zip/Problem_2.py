def no_students():
    students = 133
    chocolate = 213
    chocolate_per_student = chocolate//students
    remaining_chocolates = chocolate%students
    print(" Each student gets", chocolate_per_student , "chocolate")
    print(" Remaining bars of chocolate = ", remaining_chocolates)
    
no_students()