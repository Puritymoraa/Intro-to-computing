def no_students():
    former_students = 62
    current_students = 133
    increase = current_students - former_students
    percent_increase = (increase/former_students)*100
    print("The percentage increase = ", percent_increase)
no_students()