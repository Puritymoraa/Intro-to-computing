import math
def volume():
    radius = float(input("Please enter the radius of your tank = "))
    height = float(input("Please enter the height of your tank = "))
    volume_tank = math.pi * radius**2 * height
    print("The volume of your tank = ", round(volume_tank, 4), "cubic metres")
volume()