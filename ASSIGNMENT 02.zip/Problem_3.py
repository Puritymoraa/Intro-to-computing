import math
def cone(r,h):
    sphere_volume =(1/3)* math.pi* (r**2)*h
    print("The volume of the cone = ", round(sphere_volume, 4), "cubic centimetres")
    
cone(2.5, 4)
    